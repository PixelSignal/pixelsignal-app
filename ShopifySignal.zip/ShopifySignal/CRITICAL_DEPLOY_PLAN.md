# ⚠️ CRITICAL DEPLOY PLAN - ÚLTIMA CHANCE PIXELSIGNAL

## 🎯 OBJETIVO: INSTALAÇÃO + REINSTALAÇÃO 100% FUNCIONAL

### PONTOS CRÍTICOS IDENTIFICADOS:
1. ✅ OAuth URL generation - FUNCIONANDO
2. ✅ Token exchange - FUNCIONANDO  
3. ✅ Database storage - FUNCIONANDO
4. ❌ Webhooks POST - PROBLEMA REPLIT (será resolvido no Railway)
5. ✅ Frontend dashboard - PRONTO

### RAILWAY DEPLOY CHECKLIST:

#### PRÉ-DEPLOY:
- [x] Sistema Railway routes ativo
- [x] Build funcionando
- [x] Docker configurado
- [x] Environment variables mapeadas

#### DEPLOY RAILWAY:
1. Connect GitHub repo
2. Configure env vars:
   - SHOPIFY_API_KEY=b22969e3fff384e9ed61fe4e3490cb92
   - SHOPIFY_API_SECRET=[user_secret]
   - NODE_ENV=production

#### PÓS-DEPLOY:
1. Get Railway URL (ex: https://pixelsignal-production.up.railway.app)
2. Update Shopify Partner Dashboard:
   - App URL: [railway-url]
   - Redirect URL: [railway-url]/api/auth/callback
3. Test installation: [railway-url]/api/auth/install?shop=pixelsignal14.myshopify.com

### GARANTIAS DE SUCESSO:
- OAuth flow simplificado (sem CSRF para MVP)
- Error handling robusto
- Logging completo para debug
- Authentic data only
- No mock/placeholder data

### TESTE FINAL:
1. Install app
2. Uninstall app  
3. Reinstall app
4. Verify all logs and data

## 🚀 READY FOR DEPLOY!