import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const shopifyStores = pgTable("shopify_stores", {
  id: serial("id").primaryKey(),
  shop: text("shop").notNull().unique(),
  accessToken: text("access_token").notNull(),
  scope: text("scope").notNull(),
  isActive: boolean("is_active").default(true),
  installedAt: timestamp("installed_at").defaultNow(),
  uninstalledAt: timestamp("uninstalled_at"),
});

export const webhookLogs = pgTable("webhook_logs", {
  id: serial("id").primaryKey(),
  shop: text("shop").notNull(),
  topic: text("topic").notNull(),
  payload: text("payload").notNull(),
  hmacValid: boolean("hmac_valid").notNull(),
  processedAt: timestamp("processed_at").defaultNow(),
});

export const authLogs = pgTable("auth_logs", {
  id: serial("id").primaryKey(),
  shop: text("shop").notNull(),
  action: text("action").notNull(), // 'install', 'uninstall', 'oauth_start', 'oauth_complete'
  status: text("status").notNull(), // 'success', 'error', 'pending'
  details: text("details"),
  timestamp: timestamp("timestamp").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertShopifyStoreSchema = createInsertSchema(shopifyStores).omit({
  id: true,
  installedAt: true,
});

export const insertWebhookLogSchema = createInsertSchema(webhookLogs).omit({
  id: true,
  processedAt: true,
});

export const insertAuthLogSchema = createInsertSchema(authLogs).omit({
  id: true,
  timestamp: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertShopifyStore = z.infer<typeof insertShopifyStoreSchema>;
export type ShopifyStore = typeof shopifyStores.$inferSelect;

export type InsertWebhookLog = z.infer<typeof insertWebhookLogSchema>;
export type WebhookLog = typeof webhookLogs.$inferSelect;

export type InsertAuthLog = z.infer<typeof insertAuthLogSchema>;
export type AuthLog = typeof authLogs.$inferSelect;
