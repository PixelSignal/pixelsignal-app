# Shopify App Development Platform

## Overview

This is a full-stack web application designed for developing and managing Shopify apps. The platform provides a comprehensive dashboard for Shopify app developers to handle OAuth authentication, webhook management, and app installation tracking. It uses a modern tech stack with React on the frontend, Express.js on the backend, and PostgreSQL for data persistence.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Styling**: TailwindCSS with shadcn/ui component library
- **State Management**: React Query (@tanstack/react-query) for server state
- **Routing**: Wouter for client-side routing
- **Build Tool**: Vite for development and production builds

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Database ORM**: Drizzle ORM with PostgreSQL
- **Authentication**: Session-based auth with Shopify OAuth flow
- **Development**: tsx for TypeScript execution in development

### Database Architecture
- **Primary Database**: PostgreSQL (configured for @neondatabase/serverless)
- **Schema Management**: Drizzle Kit for migrations
- **Tables**: Users, Shopify stores, webhook logs, and auth logs

## Key Components

### 1. Shopify Integration Layer
- **OAuth Flow**: Complete Shopify app installation and authorization
- **Webhook Processing**: Secure webhook validation and logging
- **API Services**: Shopify REST API integration with proper HMAC validation
- **Store Management**: Track active/inactive Shopify store installations

### 2. Authentication System
- **Middleware**: Custom auth validation for Shopify requests
- **HMAC Verification**: Cryptographic validation of Shopify requests
- **Session Management**: Cookie-based state management for OAuth flow
- **Access Token Storage**: Secure storage of Shopify access tokens

### 3. Dashboard Interface
- **Real-time Status**: Live monitoring of app installation status
- **Development Logs**: Real-time logging of auth and webhook events
- **Quick Actions**: Testing tools for installation validation
- **Progress Tracking**: Step-by-step installation progress indicators

### 4. Logging and Monitoring
- **Audit Trail**: Complete logging of authentication attempts
- **Webhook Tracking**: Detailed webhook payload and validation logs
- **Error Handling**: Comprehensive error logging and user feedback

## Data Flow

### OAuth Installation Flow
1. User initiates installation via `/api/auth/install`
2. System generates secure state token and redirects to Shopify
3. Shopify redirects back to `/api/auth/callback` with authorization code
4. System exchanges code for access token and stores store information
5. Installation status is logged and tracked in the database

### Webhook Processing Flow
1. Shopify sends webhook to configured endpoints
2. Middleware validates HMAC signature using shared secret
3. Webhook payload and validation results are logged
4. Valid webhooks trigger appropriate business logic
5. All attempts (valid/invalid) are tracked for monitoring

### Dashboard Data Flow
1. Frontend polls `/api/status` endpoint for real-time updates
2. Server aggregates data from multiple database tables
3. React Query manages caching and automatic refetching
4. UI components reactively update based on data changes

## External Dependencies

### Shopify Services
- **Admin API**: For accessing store data and performing operations
- **OAuth Service**: For app installation and authorization
- **Webhook Service**: For receiving real-time store events

### Third-party Services
- **Neon Database**: Serverless PostgreSQL hosting
- **Replit**: Development and deployment platform

### UI Libraries
- **Radix UI**: Accessible, unstyled UI primitives
- **Lucide React**: Icon library
- **TailwindCSS**: Utility-first CSS framework

## Deployment Strategy

### Development Environment
- **Hot Reload**: Vite dev server with HMR enabled
- **Database**: Local PostgreSQL or Neon development instance
- **Environment Variables**: Required for Shopify API credentials

### Production Deployment
- **Build Process**: Vite builds frontend, esbuild bundles backend
- **Asset Serving**: Express serves static files from dist/public
- **Database Migrations**: Drizzle Kit handles schema updates
- **Environment**: Production-ready with proper error handling

### Configuration Requirements
- `DATABASE_URL`: PostgreSQL connection string
- `SHOPIFY_API_KEY`: Shopify app API key
- `SHOPIFY_API_SECRET`: Shopify app secret key
- `SHOPIFY_SCOPES`: Required app permissions
- `HOST_NAME`: Public URL for OAuth callbacks

### Security Considerations
- HMAC validation for all Shopify requests
- Secure cookie handling with httpOnly flags
- Environment-based configuration management
- Input validation and sanitization
- Rate limiting and error handling

The application is designed to be a complete development platform for Shopify app creators, providing all necessary tools for building, testing, and monitoring Shopify applications with proper security and scalability considerations.