# 🚀 Deploy PixelSignal no Railway

## Passo 1: Preparar Railway
1. Criar conta no [Railway.app](https://railway.app)
2. Conectar sua conta GitHub
3. Criar novo projeto: "New Project" → "Deploy from GitHub repo"

## Passo 2: Configurar Banco PostgreSQL
1. No Railway: "Add Service" → "Database" → "PostgreSQL"
2. Railway vai gerar automaticamente a `DATABASE_URL`

## Passo 3: Configurar Variáveis de Ambiente
No Railway Dashboard, ir em "Variables" e adicionar:

```
SHOPIFY_API_KEY=b22969e3fff384e9ed61fe4e3490cb92
SHOPIFY_API_SECRET=[seu_secret_do_partner_dashboard]
NODE_ENV=production
PORT=3000
```

## Passo 4: Atualizar Partner Dashboard
Quando o Railway der sua URL (ex: `pixelsignal-production.railway.app`):

1. **App setup** → **URLs**:
   - App URL: `https://pixelsignal-production.railway.app`
   - Allowed redirection URLs: `https://pixelsignal-production.railway.app/api/auth/callback`

2. **Webhooks**:
   - Endpoint URL: `https://pixelsignal-production.railway.app/api/webhooks/app/uninstalled`

## Passo 5: Deploy
- Railway faz deploy automático quando você fizer push no GitHub
- Build command: `npm run build` 
- Start command: `npm start`

## URLs Estáveis ✅
- OAuth funcionará 100% do tempo
- Webhooks nunca falharão  
- Shopify aprovará sem problemas

**Quer que eu te ajude com algum desses passos?**