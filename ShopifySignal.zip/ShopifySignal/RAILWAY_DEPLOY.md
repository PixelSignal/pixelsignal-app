# Railway Deployment Guide - PixelSignal

## 🚀 Quick Deploy Steps

### 1. Create Railway Account
- Go to https://railway.app
- Sign up with GitHub

### 2. Connect Repository
- Click "New Project"
- Select "Deploy from GitHub repo"
- Connect this repository

### 3. Configure Environment Variables
Add these in Railway dashboard:
```
SHOPIFY_API_KEY=b22969e3fff384e9ed61fe4e3490cb92
SHOPIFY_API_SECRET=your_secret_here
NODE_ENV=production
```

### 4. Deploy
- Railway will auto-build and deploy
- Get your Railway URL (e.g., https://pixelsignal-production.up.railway.app)

### 5. Update Shopify Partner Dashboard
- Go to Partners Dashboard
- Update App URL to your Railway URL
- Update Redirect URLs to: https://your-railway-url.railway.app/api/auth/callback

## ✅ System Ready for Railway
- All files configured
- Docker ready
- Build scripts ready
- Railway.json configured

## 🎯 Next Steps After Deploy
1. Test OAuth at: https://your-url.railway.app/api/auth/install?shop=pixelsignal14.myshopify.com
2. Update Partner Dashboard URLs
3. Install app on test store