# 🎯 PixelSignal - Shopify App for Tracking Pixels Detection

A professional Shopify app that detects and displays tracking pixels installed on Shopify stores, with real-time monitoring and management capabilities.

## ✨ Features

- 🔍 **Pixel Detection**: Automatically detect popular tracking pixels (Facebook, Google, TikTok, etc.)
- 🔐 **Secure OAuth**: Full Shopify OAuth implementation with proper authentication flow
- 📊 **Real-time Dashboard**: Live monitoring of pixel status and installation health
- 🔄 **Install/Uninstall Support**: Complete app lifecycle management
- 📝 **Audit Logging**: Comprehensive logging of all authentication and webhook events
- 🚀 **Railway Ready**: Optimized for deployment on Railway platform

## 🛠️ Tech Stack

- **Frontend**: React 18 + TypeScript + TailwindCSS + shadcn/ui
- **Backend**: Node.js + Express + TypeScript
- **Database**: PostgreSQL with in-memory storage fallback
- **Authentication**: Shopify OAuth 2.0
- **Deployment**: Railway with Docker support

## 🚀 Quick Deploy to Railway

[![Deploy on Railway](https://railway.app/button.svg)](https://railway.app)

### 1. Environment Variables
Set these in Railway dashboard:
```
SHOPIFY_API_KEY=your_shopify_api_key
SHOPIFY_API_SECRET=your_shopify_secret
NODE_ENV=production
```

### 2. Shopify Partner Dashboard Setup
- **App URL**: `https://your-railway-app.railway.app`
- **Redirect URL**: `https://your-railway-app.railway.app/api/auth/callback`
- **Required Scopes**: `read_products,read_analytics,read_pixels,write_pixels`

### 3. Test Installation
Visit: `https://your-railway-app.railway.app/api/auth/install?shop=yourstore.myshopify.com`

## 📋 Project Structure

```
├── client/           # React frontend
├── server/           # Express backend
├── shared/           # Shared types and schemas
├── railway.json      # Railway deployment config
├── nixpacks.toml     # Build configuration
└── Dockerfile        # Container configuration
```

## 🔧 Development

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Start production server
npm start
```

## 📚 API Endpoints

- `GET /api/auth/install` - Initiate OAuth installation
- `GET /api/auth/callback` - OAuth callback handler
- `GET /api/status` - Get app installation status
- `POST /api/test/installation` - Test installation health
- `GET /api/logs` - Get development logs

## 🔒 Security Features

- HMAC signature validation for all Shopify requests
- Secure session management with httpOnly cookies
- Environment-based configuration management
- Input validation and sanitization
- Comprehensive error handling and logging

## 📖 Documentation

This app follows Shopify's official development guidelines and best practices for app authentication and webhook handling.

## 🎯 Created for PixelSignal MVP

Professional Shopify app development with focus on reliability, security, and user experience.