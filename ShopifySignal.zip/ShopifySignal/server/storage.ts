import { users, shopifyStores, webhookLogs, authLogs, type User, type InsertUser, type ShopifyStore, type InsertShopifyStore, type WebhookLog, type InsertWebhookLog, type AuthLog, type InsertAuthLog } from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Shopify Store management
  getShopifyStore(shop: string): Promise<ShopifyStore | undefined>;
  createShopifyStore(store: InsertShopifyStore): Promise<ShopifyStore>;
  updateShopifyStore(shop: string, updates: Partial<ShopifyStore>): Promise<ShopifyStore | undefined>;
  deleteShopifyStore(shop: string): Promise<boolean>;
  getAllActiveStores(): Promise<ShopifyStore[]>;
  
  // Webhook logging
  createWebhookLog(log: InsertWebhookLog): Promise<WebhookLog>;
  getWebhookLogs(shop?: string, limit?: number): Promise<WebhookLog[]>;
  
  // Auth logging
  createAuthLog(log: InsertAuthLog): Promise<AuthLog>;
  getAuthLogs(shop?: string, limit?: number): Promise<AuthLog[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private stores: Map<string, ShopifyStore>;
  private webhookLogs: WebhookLog[];
  private authLogs: AuthLog[];
  private currentUserId: number;
  private currentStoreId: number;
  private currentWebhookLogId: number;
  private currentAuthLogId: number;

  constructor() {
    this.users = new Map();
    this.stores = new Map();
    this.webhookLogs = [];
    this.authLogs = [];
    this.currentUserId = 1;
    this.currentStoreId = 1;
    this.currentWebhookLogId = 1;
    this.currentAuthLogId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getShopifyStore(shop: string): Promise<ShopifyStore | undefined> {
    return this.stores.get(shop);
  }

  async createShopifyStore(insertStore: InsertShopifyStore): Promise<ShopifyStore> {
    const id = this.currentStoreId++;
    const store: ShopifyStore = {
      ...insertStore,
      id,
      isActive: true,
      installedAt: new Date(),
      uninstalledAt: null,
    };
    this.stores.set(insertStore.shop, store);
    return store;
  }

  async updateShopifyStore(shop: string, updates: Partial<ShopifyStore>): Promise<ShopifyStore | undefined> {
    const store = this.stores.get(shop);
    if (!store) return undefined;
    
    const updatedStore = { ...store, ...updates };
    this.stores.set(shop, updatedStore);
    return updatedStore;
  }

  async deleteShopifyStore(shop: string): Promise<boolean> {
    return this.stores.delete(shop);
  }

  async getAllActiveStores(): Promise<ShopifyStore[]> {
    return Array.from(this.stores.values()).filter(store => store.isActive);
  }

  async createWebhookLog(insertLog: InsertWebhookLog): Promise<WebhookLog> {
    const id = this.currentWebhookLogId++;
    const log: WebhookLog = {
      ...insertLog,
      id,
      processedAt: new Date(),
    };
    this.webhookLogs.push(log);
    return log;
  }

  async getWebhookLogs(shop?: string, limit = 50): Promise<WebhookLog[]> {
    let logs = this.webhookLogs;
    
    if (shop) {
      logs = logs.filter(log => log.shop === shop);
    }
    
    return logs
      .sort((a, b) => (b.processedAt?.getTime() || 0) - (a.processedAt?.getTime() || 0))
      .slice(0, limit);
  }

  async createAuthLog(insertLog: InsertAuthLog): Promise<AuthLog> {
    const id = this.currentAuthLogId++;
    const log: AuthLog = {
      ...insertLog,
      id,
      timestamp: new Date(),
    };
    this.authLogs.push(log);
    return log;
  }

  async getAuthLogs(shop?: string, limit = 50): Promise<AuthLog[]> {
    let logs = this.authLogs;
    
    if (shop) {
      logs = logs.filter(log => log.shop === shop);
    }
    
    return logs
      .sort((a, b) => (b.timestamp?.getTime() || 0) - (a.timestamp?.getTime() || 0))
      .slice(0, limit);
  }
}

export const storage = new MemStorage();
