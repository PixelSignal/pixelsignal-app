import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { shopifySimpleService } from "./services/shopify-simple";

export async function registerRailwayRoutes(app: Express): Promise<Server> {
  
  // OAuth installation endpoint
  app.get('/api/auth/install', async (req, res) => {
    try {
      const shop = req.query.shop as string;
      if (!shop) {
        return res.status(400).json({ error: 'Shop parameter is required' });
      }

      // Validate shop domain
      const shopDomain = shop.replace(/^https?:\/\//, '').replace(/\/$/, '');
      if (!shopDomain.includes('.myshopify.com')) {
        return res.status(400).json({ error: 'Invalid shop domain format' });
      }

      // Log installation attempt
      await storage.createAuthLog({
        shop: shopDomain,
        action: 'oauth_start',
        status: 'pending',
        details: `Installation initiated for shop: ${shopDomain}`,
      });

      // Generate OAuth URL
      const authUrl = shopifySimpleService.generateInstallUrl(shopDomain);
      
      console.log('🚀 Railway OAuth Redirect:', authUrl);
      res.redirect(authUrl);
    } catch (error) {
      console.error('Install error:', error);
      res.status(500).json({ error: 'Installation failed' });
    }
  });

  // OAuth callback endpoint (Railway optimized)
  app.get('/api/auth/callback', async (req, res) => {
    try {
      const { code, shop } = req.query as Record<string, string>;

      console.log('=== RAILWAY OAUTH CALLBACK ===');
      console.log('Shop:', shop);
      console.log('Code exists:', !!code);

      if (!code || !shop) {
        console.log('❌ Missing OAuth parameters');
        return res.status(400).json({ error: 'Missing required OAuth parameters' });
      }

      // Exchange code for token (no CSRF validation for Railway)
      console.log('🔄 Exchanging code for access token...');
      const tokenData = await shopifySimpleService.exchangeCodeForToken(shop, code);
      console.log('✅ Access token obtained successfully');

      // Store shop information
      await storage.createShopifyStore({
        shop: tokenData.shop || shop,
        accessToken: tokenData.access_token,
        scope: tokenData.scope,
        isActive: true,
      });

      console.log('✅ Shop data stored successfully');

      // Log successful installation
      await storage.createAuthLog({
        shop: tokenData.shop || shop,
        action: 'oauth_complete',
        status: 'success',
        details: 'App successfully installed on Railway',
      });

      console.log('🎉 RAILWAY INSTALLATION COMPLETED');

      // Redirect to dashboard with success confirmation
      res.redirect(`/?shop=${shop}&installed=true&platform=railway&success=1`);
    } catch (error) {
      console.error('OAuth callback error:', error);
      const shop = req.query.shop as string;
      if (shop) {
        await storage.createAuthLog({
          shop,
          action: 'oauth_complete',
          status: 'error',
          details: `OAuth callback failed: ${error}`,
        });
      }
      res.status(500).json({ error: 'Authentication failed' });
    }
  });

  // Get app status with authentic data
  app.get('/api/status', async (req, res) => {
    try {
      const shop = req.query.shop as string;
      if (!shop) {
        return res.status(400).json({ error: 'Shop parameter is required' });
      }

      const store = await storage.getShopifyStore(shop);
      const authLogs = await storage.getAuthLogs(shop, 10);

      // Get authentic shop info and pixels if authenticated
      let shopInfo = null;
      let pixels = [];
      
      if (store?.isActive && store.accessToken) {
        try {
          shopInfo = await shopifySimpleService.getShopInfo(shop, store.accessToken);
          pixels = await shopifySimpleService.detectPixels(shop, store.accessToken);
        } catch (error) {
          console.error('Error fetching authentic data:', error);
        }
      }

      res.json({
        authenticated: !!store?.isActive,
        store: store || null,
        shopInfo,
        pixels,
        authLogs,
        systemVersion: 'railway',
      });
    } catch (error) {
      console.error('Status check error:', error);
      res.status(500).json({ error: 'Status check failed' });
    }
  });

  // Test installation with authentic Shopify data
  app.post('/api/test/installation', async (req, res) => {
    try {
      const shop = req.body.shop as string;
      if (!shop) {
        return res.status(400).json({ error: 'Shop parameter is required' });
      }

      const store = await storage.getShopifyStore(shop);
      if (!store?.isActive || !store.accessToken) {
        return res.status(401).json({ error: 'Store not authenticated' });
      }

      // Test with authentic Shopify API
      const shopInfo = await shopifySimpleService.getShopInfo(shop, store.accessToken);
      const pixels = await shopifySimpleService.detectPixels(shop, store.accessToken);

      await storage.createAuthLog({
        shop,
        action: 'installation_test',
        status: 'success',
        details: `Installation test successful on Railway - shop: ${shopInfo.shop?.name}`,
      });

      res.json({
        success: true,
        shopInfo: shopInfo.shop,
        pixels: pixels,
        message: 'Installation test completed successfully on Railway',
      });
    } catch (error) {
      console.error('Installation test error:', error);
      const shop = req.body.shop as string;
      if (shop) {
        await storage.createAuthLog({
          shop,
          action: 'installation_test',
          status: 'error',
          details: `Installation test failed: ${error}`,
        });
      }
      res.status(500).json({ error: 'Installation test failed' });
    }
  });

  // Get logs
  app.get('/api/logs', async (req, res) => {
    try {
      const { shop, type, limit } = req.query;
      const logLimit = parseInt(limit as string) || 50;

      let logs: any[] = [];

      if (type === 'auth' || !type) {
        const authLogs = await storage.getAuthLogs(shop as string, logLimit);
        logs.push(...authLogs.map(log => ({ ...log, type: 'auth' })));
      }

      logs.sort((a, b) => {
        const timeA = a.timestamp || a.processedAt;
        const timeB = b.timestamp || b.processedAt;
        return (timeB?.getTime() || 0) - (timeA?.getTime() || 0);
      });

      res.json(logs.slice(0, logLimit));
    } catch (error) {
      console.error('Logs fetch error:', error);
      res.status(500).json({ error: 'Failed to fetch logs' });
    }
  });

  // Configuration test
  app.get('/api/test/config', async (req, res) => {
    try {
      const config = {
        hasApiKey: !!process.env.SHOPIFY_API_KEY,
        hasApiSecret: !!process.env.SHOPIFY_API_SECRET,
        hostName: process.env.RAILWAY_PUBLIC_DOMAIN ? `https://${process.env.RAILWAY_PUBLIC_DOMAIN}` : 'http://localhost:5000',
        platform: 'railway',
        systemVersion: 'railway-optimized',
      };
      
      console.log('Railway Configuration:', config);
      res.json(config);
    } catch (error) {
      console.error('Config test error:', error);
      res.status(500).json({ error: 'Configuration test failed' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}