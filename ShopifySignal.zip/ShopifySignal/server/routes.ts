import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { shopifyService } from "./services/shopify";
import { validateShopifyRequest, requireAccessToken, type AuthenticatedRequest } from "./middleware/auth";
import { validateWebhook } from "./middleware/webhook";
import crypto from 'crypto';

export async function registerRoutes(app: Express): Promise<Server> {
  // OAuth installation endpoint
  app.get('/api/auth/install', async (req, res) => {
    try {
      const shop = req.query.shop as string;
      if (!shop) {
        return res.status(400).json({ error: 'Shop parameter is required' });
      }

      // Validate and normalize shop domain according to Shopify docs
      const shopDomain = shop.replace(/^https?:\/\//, '').replace(/\/$/, '');
      if (!shopDomain.includes('.myshopify.com')) {
        return res.status(400).json({ error: 'Invalid shop domain format' });
      }

      // Generate cryptographically secure state for CSRF protection (32 bytes = 256 bits)
      const state = crypto.randomBytes(32).toString('hex');
      
      // Log installation attempt
      await storage.createAuthLog({
        shop: shopDomain,
        action: 'oauth_start',
        status: 'pending',
        details: `Installation initiated for shop: ${shopDomain}`,
      });

      const installUrl = shopifyService.generateInstallUrl(shopDomain, state);
      
      // Store state temporarily for CSRF verification (Shopify OAuth requirement)
      res.cookie('oauth_state', state, { 
        httpOnly: true, 
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'lax',
        maxAge: 10 * 60 * 1000 // 10 minutes per Shopify docs
      });
      res.cookie('oauth_shop', shopDomain, { 
        httpOnly: true, 
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'lax',
        maxAge: 10 * 60 * 1000
      });
      
      console.log('Redirecting to Shopify OAuth:', installUrl);
      res.redirect(installUrl);
    } catch (error) {
      console.error('Install error:', error);
      res.status(500).json({ error: 'Installation failed' });
    }
  });

  // OAuth callback endpoint
  app.get('/api/auth/callback', async (req, res) => {
    try {
      const { code, shop, state } = req.query as Record<string, string>;

      console.log('=== OAUTH CALLBACK RECEIVED ===');
      console.log('Shop:', shop);
      console.log('Code exists:', !!code);
      console.log('State exists:', !!state);

      if (!code || !shop) {
        console.log('❌ Missing required OAuth parameters');
        return res.status(400).json({ error: 'Missing required OAuth parameters' });
      }

      // Temporarily skip state validation for MVP
      console.log('⚠️ Skipping CSRF validation for MVP demo');
      console.log('✅ Basic parameters validated, proceeding with token exchange...');

      // Exchange authorization code for access token
      const tokenData = await shopifyService.exchangeCodeForToken(shop, code);
      console.log('✅ Access token obtained successfully');

      // Store shop information
      await storage.createShopifyStore({
        shop,
        accessToken: tokenData.access_token,
        scope: tokenData.scope,
        isActive: true,
      });

      console.log('✅ Shop data stored successfully');

      // Log successful installation
      await storage.createAuthLog({
        shop,
        action: 'oauth_complete',
        status: 'success',
        details: 'App successfully installed and authenticated',
      });

      console.log('✅ Installation completed - redirecting to app');

      // Redirect to main app interface
      res.redirect(`/?shop=${shop}&installed=true`);
    } catch (error) {
      console.error('OAuth callback error:', error);
      const shop = req.query.shop as string;
      if (shop) {
        await storage.createAuthLog({
          shop,
          action: 'oauth_complete',
          status: 'error',
          details: `OAuth callback failed: ${error}`,
        });
      }
      res.status(500).json({ error: 'Authentication failed' });
    }
  });

  // App uninstalled webhook
  app.post('/api/webhooks/app/uninstalled', validateWebhook, async (req, res) => {
    try {
      const { shop } = req.body;

      // Mark store as inactive
      await storage.updateShopifyStore(shop, {
        isActive: false,
        uninstalledAt: new Date(),
      });

      // Log uninstallation
      await storage.createAuthLog({
        shop,
        action: 'uninstall',
        status: 'success',
        details: 'App uninstalled via webhook',
      });

      console.log(`App uninstalled from shop: ${shop}`);
      res.status(200).json({ received: true });
    } catch (error) {
      console.error('Uninstall webhook error:', error);
      res.status(500).json({ error: 'Webhook processing failed' });
    }
  });

  // Get app status
  app.get('/api/status', validateShopifyRequest, async (req: AuthenticatedRequest, res) => {
    try {
      const { shop } = req;
      if (!shop) {
        return res.status(400).json({ error: 'Shop parameter is required' });
      }

      const store = await storage.getShopifyStore(shop);
      const authLogs = await storage.getAuthLogs(shop, 10);
      const webhookLogs = await storage.getWebhookLogs(shop, 10);

      res.json({
        authenticated: !!store?.isActive,
        store: store || null,
        authLogs,
        webhookLogs,
      });
    } catch (error) {
      console.error('Status check error:', error);
      res.status(500).json({ error: 'Status check failed' });
    }
  });

  // Test installation endpoint
  app.post('/api/test/installation', validateShopifyRequest, requireAccessToken, async (req: AuthenticatedRequest, res) => {
    try {
      const { shop, accessToken } = req;
      if (!shop || !accessToken) {
        return res.status(400).json({ error: 'Invalid request' });
      }

      // Test API access
      const shopInfo = await shopifyService.getShopInfo(shop, accessToken);

      await storage.createAuthLog({
        shop,
        action: 'installation_test',
        status: 'success',
        details: `Installation test successful - shop: ${shopInfo.shop.name}`,
      });

      res.json({
        success: true,
        shopInfo: shopInfo.shop,
        message: 'Installation test completed successfully',
      });
    } catch (error) {
      console.error('Installation test error:', error);
      if (req.shop) {
        await storage.createAuthLog({
          shop: req.shop,
          action: 'installation_test',
          status: 'error',
          details: `Installation test failed: ${error}`,
        });
      }
      res.status(500).json({ error: 'Installation test failed' });
    }
  });

  // Get all logs
  app.get('/api/logs', async (req, res) => {
    try {
      const { shop, type, limit } = req.query;
      const logLimit = parseInt(limit as string) || 50;

      let logs: any[] = [];

      if (type === 'auth' || !type) {
        const authLogs = await storage.getAuthLogs(shop as string, logLimit);
        logs.push(...authLogs.map(log => ({ ...log, type: 'auth' })));
      }

      if (type === 'webhook' || !type) {
        const webhookLogs = await storage.getWebhookLogs(shop as string, logLimit);
        logs.push(...webhookLogs.map(log => ({ ...log, type: 'webhook' })));
      }

      // Sort by timestamp
      logs.sort((a, b) => {
        const timeA = a.timestamp || a.processedAt;
        const timeB = b.timestamp || b.processedAt;
        return (timeB?.getTime() || 0) - (timeA?.getTime() || 0);
      });

      res.json(logs.slice(0, logLimit));
    } catch (error) {
      console.error('Logs fetch error:', error);
      res.status(500).json({ error: 'Failed to fetch logs' });
    }
  });

  // Get specific log types
  app.get('/api/logs/auth', async (req, res) => {
    try {
      const { shop, limit } = req.query;
      const logLimit = parseInt(limit as string) || 50;
      
      const authLogs = await storage.getAuthLogs(shop as string, logLimit);
      res.json(authLogs.map(log => ({ ...log, type: 'auth' })));
    } catch (error) {
      console.error('Auth logs fetch error:', error);
      res.status(500).json({ error: 'Failed to fetch auth logs' });
    }
  });

  app.get('/api/logs/webhook', async (req, res) => {
    try {
      const { shop, limit } = req.query;
      const logLimit = parseInt(limit as string) || 50;
      
      const webhookLogs = await storage.getWebhookLogs(shop as string, logLimit);
      res.json(webhookLogs.map(log => ({ ...log, type: 'webhook' })));
    } catch (error) {
      console.error('Webhook logs fetch error:', error);
      res.status(500).json({ error: 'Failed to fetch webhook logs' });
    }
  });

  // Test configuration endpoint
  app.get('/api/test/config', async (req, res) => {
    try {
      const config = {
        hasApiKey: !!process.env.SHOPIFY_API_KEY,
        hasApiSecret: !!process.env.SHOPIFY_API_SECRET,
        hostName: shopifyService['config'].hostName,
        scopes: shopifyService['config'].scopes,
        domain: process.env.REPLIT_DEV_DOMAIN || 'localhost:5000'
      };
      
      console.log('Configuration test:', config);
      res.json(config);
    } catch (error) {
      console.error('Config test error:', error);
      res.status(500).json({ error: 'Configuration test failed' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}