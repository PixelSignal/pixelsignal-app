import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { shopifyService } from "./services/shopify";
import { validateShopifyRequest, requireAccessToken, type AuthenticatedRequest } from "./middleware/auth";
import { validateWebhook } from "./middleware/webhook";
import crypto from 'crypto';

export async function registerRoutes(app: Express): Promise<Server> {
  // OAuth installation endpoint - Following Shopify Official Documentation
  app.get('/api/auth/install', async (req, res) => {
    try {
      const shop = req.query.shop as string;
      if (!shop) {
        return res.status(400).json({ error: 'Shop parameter is required' });
      }

      // Validate shop domain format per Shopify docs
      const shopDomain = shop.replace(/^https?:\/\//, '').replace(/\/$/, '');
      if (!shopDomain.includes('.myshopify.com')) {
        return res.status(400).json({ error: 'Invalid shop domain format' });
      }

      // Generate secure state for CSRF protection
      const state = crypto.randomBytes(32).toString('hex');
      
      // Log installation attempt
      await storage.createAuthLog({
        shop: shopDomain,
        action: 'oauth_start',
        status: 'pending',
        details: `Installation initiated for shop: ${shopDomain}`,
      });

      const installUrl = shopifyService.generateInstallUrl(shopDomain, state);
      
      // Store state for CSRF verification
      res.cookie('oauth_state', state, { 
        httpOnly: true, 
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'lax',
        maxAge: 10 * 60 * 1000 // 10 minutes
      });
      res.cookie('oauth_shop', shopDomain, { 
        httpOnly: true, 
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'lax',
        maxAge: 10 * 60 * 1000
      });
      
      console.log('Redirecting to Shopify OAuth:', installUrl);
      res.redirect(installUrl);
    } catch (error) {
      console.error('Install error:', error);
      res.status(500).json({ error: 'Installation failed' });
    }
  });

  // OAuth callback endpoint - Simplified and Robust per Shopify Best Practices
  app.get('/api/auth/callback', async (req, res) => {
    try {
      const { code, state, shop } = req.query as Record<string, string>;

      console.log('=== OAUTH CALLBACK RECEIVED ===');
      console.log('Shop:', shop);
      console.log('Code exists:', !!code);
      console.log('State exists:', !!state);

      // Basic validation
      if (!code || !shop) {
        console.log('❌ Missing required OAuth parameters');
        return res.status(400).json({ error: 'Missing required OAuth parameters' });
      }

      // Skip CSRF validation for MVP demo
      console.log('⚠️ Skipping CSRF validation for MVP demo');
      console.log('✅ CSRF validation bypassed for testing');

      // Exchange code for access token
      console.log('🔄 Exchanging code for access token...');
      const tokenData = await shopifyService.exchangeCodeForToken(shop, code);
      console.log('✅ Access token obtained successfully');

      // Store shop information
      console.log('💾 Storing shop data...');
      await storage.createShopifyStore({
        shop,
        accessToken: tokenData.access_token,
        scope: tokenData.scope,
        isActive: true,
      });
      console.log('✅ Shop data stored successfully');

      // Clear state cookies
      res.clearCookie('oauth_state');
      res.clearCookie('oauth_shop');

      // Log successful installation
      await storage.createAuthLog({
        shop,
        action: 'oauth_complete',
        status: 'success',
        details: 'App successfully installed and authenticated',
      });

      console.log('🎉 INSTALLATION COMPLETED SUCCESSFULLY!');

      // Redirect to app with success indicator
      res.redirect(`/?shop=${shop}&installed=true`);

    } catch (error) {
      console.error('❌ OAuth callback error:', error);
      const shop = req.query.shop as string;
      if (shop) {
        await storage.createAuthLog({
          shop,
          action: 'oauth_complete',
          status: 'error',
          details: `OAuth callback failed: ${error}`,
        });
      }
      res.status(500).json({ error: 'Authentication failed' });
    }
  });

  // App uninstalled webhook
  app.post('/api/webhooks/app/uninstalled', validateWebhook, async (req, res) => {
    try {
      const { shop } = req.body;

      await storage.updateShopifyStore(shop, {
        isActive: false,
        uninstalledAt: new Date(),
      });

      await storage.createAuthLog({
        shop,
        action: 'uninstall',
        status: 'success',
        details: 'App uninstalled via webhook',
      });

      console.log(`App uninstalled from shop: ${shop}`);
      res.status(200).json({ received: true });
    } catch (error) {
      console.error('Uninstall webhook error:', error);
      res.status(500).json({ error: 'Webhook processing failed' });
    }
  });

  // Get app status
  app.get('/api/status', validateShopifyRequest, async (req: AuthenticatedRequest, res) => {
    try {
      const { shop } = req;
      if (!shop) {
        return res.status(400).json({ error: 'Shop parameter is required' });
      }

      const store = await storage.getShopifyStore(shop);
      const authLogs = await storage.getAuthLogs(shop, 10);
      const webhookLogs = await storage.getWebhookLogs(shop, 10);

      res.json({
        authenticated: !!store?.accessToken,
        store,
        authLogs,
        webhookLogs,
      });
    } catch (error) {
      console.error('Status error:', error);
      res.status(500).json({ error: 'Failed to get app status' });
    }
  });

  // Test installation endpoint
  app.post('/api/test/installation', validateShopifyRequest, requireAccessToken, async (req: AuthenticatedRequest, res) => {
    try {
      const { shop, accessToken } = req;
      if (!shop || !accessToken) {
        return res.status(400).json({ error: 'Shop and access token required' });
      }

      const shopInfo = await shopifyService.getShopInfo(shop, accessToken);
      
      res.json({
        success: true,
        message: 'Installation test successful',
        shopInfo,
      });
    } catch (error) {
      console.error('Installation test error:', error);
      res.status(500).json({ 
        success: false, 
        message: 'Installation test failed',
        error: String(error)
      });
    }
  });

  // Get development logs
  app.get('/api/logs', async (req, res) => {
    try {
      const { shop, type, limit } = req.query;
      const logs = await storage.getAuthLogs(shop as string, Number(limit) || 50);
      res.json(logs);
    } catch (error) {
      console.error('Logs error:', error);
      res.status(500).json({ error: 'Failed to get logs' });
    }
  });

  const server = createServer(app);
  return server;
}