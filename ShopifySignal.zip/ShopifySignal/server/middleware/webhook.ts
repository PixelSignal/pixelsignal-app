import { Request, Response, NextFunction } from 'express';
import { shopifyService } from '../services/shopify';
import { storage } from '../storage';

export async function validateWebhook(req: Request, res: Response, next: NextFunction) {
  try {
    const signature = req.headers['x-shopify-hmac-sha256'] as string;
    const shop = req.headers['x-shopify-shop-domain'] as string;
    const topic = req.headers['x-shopify-topic'] as string;

    if (!signature || !shop || !topic) {
      return res.status(400).json({ error: 'Missing required webhook headers' });
    }

    const payload = JSON.stringify(req.body);
    const isValid = shopifyService.verifyWebhookSignature(payload, signature);

    // Log webhook attempt
    await storage.createWebhookLog({
      shop,
      topic,
      payload,
      hmacValid: isValid,
    });

    if (!isValid) {
      console.error('Invalid webhook signature from shop:', shop);
      return res.status(401).json({ error: 'Invalid webhook signature' });
    }

    req.body.shop = shop;
    req.body.topic = topic;
    next();
  } catch (error) {
    console.error('Webhook validation error:', error);
    res.status(500).json({ error: 'Webhook validation failed' });
  }
}
