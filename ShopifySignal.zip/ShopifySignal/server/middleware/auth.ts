import { Request, Response, NextFunction } from 'express';
import { storage } from '../storage';
import { shopifyService } from '../services/shopify';

export interface AuthenticatedRequest extends Request {
  shop?: string;
  accessToken?: string;
}

export async function validateShopifyRequest(
  req: AuthenticatedRequest, 
  res: Response, 
  next: NextFunction
) {
  try {
    const shop = req.query.shop as string || req.headers['x-shopify-shop-domain'] as string;
    
    if (!shop) {
      return res.status(400).json({ error: 'Shop parameter is required' });
    }

    // Verify HMAC if present
    if (req.query.hmac) {
      const isValidHmac = shopifyService.verifyHmac(req.query as Record<string, string>);
      if (!isValidHmac) {
        await storage.createAuthLog({
          shop,
          action: 'hmac_validation',
          status: 'error',
          details: 'Invalid HMAC signature',
        });
        return res.status(401).json({ error: 'Invalid HMAC signature' });
      }
    }

    req.shop = shop;
    next();
  } catch (error) {
    console.error('Auth validation error:', error);
    res.status(500).json({ error: 'Authentication validation failed' });
  }
}

export async function requireAccessToken(
  req: AuthenticatedRequest, 
  res: Response, 
  next: NextFunction
) {
  try {
    if (!req.shop) {
      return res.status(400).json({ error: 'Shop not identified' });
    }

    const store = await storage.getShopifyStore(req.shop);
    if (!store || !store.isActive) {
      return res.status(401).json({ error: 'Store not found or inactive' });
    }

    req.accessToken = store.accessToken;
    next();
  } catch (error) {
    console.error('Access token validation error:', error);
    res.status(500).json({ error: 'Access token validation failed' });
  }
}
