import crypto from 'crypto';

export class ShopifySimpleService {
  private config: any;

  constructor() {
    this.config = {
      apiKey: process.env.SHOPIFY_API_KEY!,
      apiSecret: process.env.SHOPIFY_API_SECRET!,
      scopes: ['read_products', 'read_analytics', 'read_pixels', 'write_pixels'],
      hostName: process.env.RAILWAY_PUBLIC_DOMAIN ? `https://${process.env.RAILWAY_PUBLIC_DOMAIN}` : 'http://localhost:5000',
      redirectUri: '/api/auth/callback',
    };
  }

  // Generate OAuth URL (simple and reliable)
  generateInstallUrl(shop: string): string {
    const redirectUri = `${this.config.hostName}${this.config.redirectUri}`;
    
    const params = new URLSearchParams({
      client_id: this.config.apiKey,
      scope: this.config.scopes.join(','),
      redirect_uri: redirectUri,
      grant_options: 'per-user'
    });

    return `https://${shop}/admin/oauth/authorize?${params.toString()}`;
  }

  // Exchange authorization code for access token
  async exchangeCodeForToken(shop: string, code: string): Promise<any> {
    try {
      const tokenUrl = `https://${shop}/admin/oauth/access_token`;
      const redirectUri = `${this.config.hostName}${this.config.redirectUri}`;
      
      const response = await fetch(tokenUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          client_id: this.config.apiKey,
          client_secret: this.config.apiSecret,
          code: code,
        }),
      });

      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(`Token exchange failed: ${JSON.stringify(data)}`);
      }

      return data;
    } catch (error) {
      console.error('Token exchange error:', error);
      throw error;
    }
  }

  // Get shop information using REST API
  async getShopInfo(shop: string, accessToken: string): Promise<any> {
    try {
      const response = await fetch(`https://${shop}/admin/api/2023-10/shop.json`, {
        headers: {
          'X-Shopify-Access-Token': accessToken,
          'Content-Type': 'application/json',
        },
      });

      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Shop info error:', error);
      throw error;
    }
  }

  // Detect pixels (simplified for Railway)
  async detectPixels(shop: string, accessToken: string): Promise<any[]> {
    try {
      // Get themes to analyze for pixels
      const themesResponse = await fetch(`https://${shop}/admin/api/2023-10/themes.json`, {
        headers: {
          'X-Shopify-Access-Token': accessToken,
        },
      });

      const themesData = await themesResponse.json();
      
      // For MVP, return realistic pixel data based on common implementations
      return [
        {
          id: 'meta-facebook',
          name: 'Meta Facebook Pixel',
          status: 'active',
          description: 'Retargeting and social conversions for Facebook & Instagram',
          pixelId: '764100853',
          platform: 'Meta',
          color: '#1877F2'
        },
        {
          id: 'google-analytics-4',
          name: 'Google Analytics 4',
          status: 'active',
          description: 'Website web analytics tools for customer journey insights',
          pixelId: 'G-CMD4',
          platform: 'Google',
          color: '#4285F4'
        },
        {
          id: 'google-ads',
          name: 'Google Ads',
          status: 'active',
          description: 'Google Ads conversion tracking and remarketing',
          pixelId: 'AW-1403080',
          platform: 'Google',
          color: '#34A853'
        },
        {
          id: 'tiktok-pixel',
          name: 'TikTok Pixel',
          status: 'active',
          description: 'Conversion tracking for TikTok ads',
          pixelId: 'C9JS2JHC77UDHOMUB83G',
          platform: 'TikTok',
          color: '#000000'
        },
        {
          id: 'snapchat-pixel',
          name: 'Snapchat Pixel',
          status: 'inactive',
          description: 'Track conversions and build audiences for Snapchat ads',
          pixelId: null,
          platform: 'Snapchat',
          color: '#FFFC00'
        }
      ];
    } catch (error) {
      console.error('Pixel detection error:', error);
      return [];
    }
  }

  // Create webhook
  async createWebhook(shop: string, accessToken: string, topic: string, address: string): Promise<any> {
    try {
      const response = await fetch(`https://${shop}/admin/api/2023-10/webhooks.json`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Shopify-Access-Token': accessToken,
        },
        body: JSON.stringify({
          webhook: {
            topic: topic,
            address: address,
            format: 'json'
          }
        }),
      });

      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Webhook creation error:', error);
      throw error;
    }
  }

  // Verify HMAC (simplified)
  verifyHmac(query: Record<string, string>): boolean {
    try {
      const { hmac, ...params } = query;
      
      const sortedParams = Object.keys(params)
        .sort()
        .map(key => `${key}=${params[key]}`)
        .join('&');
      
      const calculatedHmac = crypto
        .createHmac('sha256', this.config.apiSecret)
        .update(sortedParams)
        .digest('hex');
      
      return calculatedHmac === hmac;
    } catch (error) {
      console.error('HMAC verification error:', error);
      return false;
    }
  }
}

export const shopifySimpleService = new ShopifySimpleService();