import { shopifyApi, LATEST_API_VERSION, Session } from '@shopify/shopify-api';
import { storage } from '../storage';

// Initialize Shopify API with official library
const shopify = shopifyApi({
  apiKey: process.env.SHOPIFY_API_KEY!,
  apiSecretKey: process.env.SHOPIFY_API_SECRET!,
  scopes: ['read_products', 'read_analytics', 'read_pixels', 'write_pixels'],
  hostName: process.env.REPLIT_DEV_DOMAIN ? `https://${process.env.REPLIT_DEV_DOMAIN}` : 'http://localhost:5000',
  apiVersion: LATEST_API_VERSION,
  isEmbeddedApp: false,
});

export class ShopifyOfficialService {
  
  // Generate OAuth URL using official library
  generateAuthUrl(shop: string): string {
    const authRoute = `/api/auth/callback`;
    return shopify.auth.buildAuthURL({
      shop,
      redirectUri: `${shopify.config.hostName}${authRoute}`,
      state: `${shop}-${Date.now()}`, // Simple state for CSRF protection
    });
  }

  // Exchange code for token using official library
  async exchangeCodeForToken(shop: string, code: string, state: string) {
    try {
      const session = shopify.auth.buildSession({ shop, code, state });
      const { session: validatedSession } = await shopify.auth.validateAuthCallback({
        rawRequest: {
          url: `${shopify.config.hostName}/api/auth/callback?code=${code}&shop=${shop}&state=${state}`,
          method: 'GET',
          headers: {},
        },
        rawResponse: {} as any,
      });

      return {
        accessToken: validatedSession.accessToken,
        scope: validatedSession.scope,
        shop: validatedSession.shop,
      };
    } catch (error) {
      console.error('Token exchange error:', error);
      throw error;
    }
  }

  // Get shop info using GraphQL with official library
  async getShopInfo(shop: string, accessToken: string) {
    try {
      const session = new Session({
        id: `${shop}-session`,
        shop,
        accessToken,
        isOnline: false,
      });

      const client = new shopify.clients.Graphql({ session });
      
      const query = `
        query {
          shop {
            id
            name
            email
            domain
            myshopifyDomain
            plan {
              displayName
            }
          }
        }
      `;

      const response = await client.query({ data: query });
      return response.body;
    } catch (error) {
      console.error('Shop info error:', error);
      throw error;
    }
  }

  // Get pixels using Admin API
  async getPixels(shop: string, accessToken: string) {
    try {
      const session = new Session({
        id: `${shop}-pixels`,
        shop,
        accessToken,
        isOnline: false,
      });

      const client = new shopify.clients.Rest({ session });
      
      // Get web pixels (new Shopify Customer Events API)
      const pixelsResponse = await client.get({
        path: 'pixels',
      });

      return pixelsResponse.body;
    } catch (error) {
      console.error('Pixels fetch error:', error);
      // Return empty array if pixels API is not available
      return { pixels: [] };
    }
  }

  // Create webhook using official library
  async createWebhook(shop: string, accessToken: string, topic: string, address: string) {
    try {
      const session = new Session({
        id: `${shop}-webhook`,
        shop,
        accessToken,
        isOnline: false,
      });

      const webhook = new shopify.rest.Webhook({ session });
      webhook.topic = topic;
      webhook.address = address;
      webhook.format = 'json';
      
      await webhook.save({ update: true });
      return webhook;
    } catch (error) {
      console.error('Webhook creation error:', error);
      throw error;
    }
  }
}

export const shopifyOfficialService = new ShopifyOfficialService();