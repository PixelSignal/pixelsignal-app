import crypto from 'crypto';

export interface ShopifyConfig {
  apiKey: string;
  apiSecret: string;
  scopes: string[];
  hostName: string;
}

export class ShopifyService {
  private config: ShopifyConfig;

  constructor(config: ShopifyConfig) {
    this.config = config;
  }

  generateInstallUrl(shop: string, state: string): string {
    const params = new URLSearchParams({
      client_id: this.config.apiKey,
      scope: this.config.scopes.join(','),
      redirect_uri: `${this.config.hostName}/api/auth/callback`,
      state,
      'grant_options[]': 'per-user',
    });

    return `https://${shop}/admin/oauth/authorize?${params.toString()}`;
  }

  async exchangeCodeForToken(shop: string, code: string): Promise<{
    access_token: string;
    scope: string;
  }> {
    const response = await fetch(`https://${shop}/admin/oauth/access_token`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        client_id: this.config.apiKey,
        client_secret: this.config.apiSecret,
        code,
      }),
    });

    if (!response.ok) {
      throw new Error(`Failed to exchange code for token: ${response.statusText}`);
    }

    return response.json();
  }

  verifyWebhookSignature(payload: string, signature: string): boolean {
    const calculatedSignature = crypto
      .createHmac('sha256', this.config.apiSecret)
      .update(payload, 'utf8')
      .digest('base64');

    return crypto.timingSafeEqual(
      Buffer.from(signature, 'base64'),
      Buffer.from(calculatedSignature, 'base64')
    );
  }

  verifyHmac(query: Record<string, string>): boolean {
    const { hmac, signature, ...params } = query;
    
    // Remove any undefined or null values and sort parameters
    const sortedParams = Object.keys(params)
      .filter(key => params[key] !== undefined && params[key] !== null)
      .sort()
      .map(key => `${key}=${encodeURIComponent(params[key])}`)
      .join('&');

    const calculatedHmac = crypto
      .createHmac('sha256', this.config.apiSecret)
      .update(sortedParams, 'utf8')
      .digest('hex');

    return crypto.timingSafeEqual(
      Buffer.from(hmac, 'hex'),
      Buffer.from(calculatedHmac, 'hex')
    );
  }

  async createWebhook(shop: string, accessToken: string, topic: string, address: string): Promise<any> {
    const response = await fetch(`https://${shop}/admin/api/2024-01/webhooks.json`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Shopify-Access-Token': accessToken,
      },
      body: JSON.stringify({
        webhook: {
          topic,
          address,
          format: 'json',
        },
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Failed to create webhook: ${response.status} ${response.statusText} - ${errorText}`);
    }

    return response.json();
  }

  async getShopInfo(shop: string, accessToken: string): Promise<any> {
    const response = await fetch(`https://${shop}/admin/api/2024-01/shop.json`, {
      headers: {
        'X-Shopify-Access-Token': accessToken,
      },
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Failed to get shop info: ${response.status} ${response.statusText} - ${errorText}`);
    }

    return response.json();
  }
}

export const shopifyService = new ShopifyService({
  apiKey: process.env.SHOPIFY_API_KEY || '',
  apiSecret: process.env.SHOPIFY_API_SECRET || '',
  scopes: ['read_products', 'read_analytics', 'read_pixels', 'write_pixels'],
  hostName: 'https://shopifysignal--info4292.replit.app',
});
