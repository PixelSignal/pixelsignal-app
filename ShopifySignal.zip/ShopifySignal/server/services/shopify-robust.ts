import Shopify from 'node-shopify-api';
import crypto from 'crypto-js';
import jwt from 'jsonwebtoken';
import axios from 'axios';

export class ShopifyRobustService {
  private config: any;

  constructor() {
    this.config = {
      apiKey: process.env.SHOPIFY_API_KEY!,
      apiSecret: process.env.SHOPIFY_API_SECRET!,
      scopes: ['read_products', 'read_analytics', 'read_pixels', 'write_pixels'],
      hostName: process.env.REPLIT_DEV_DOMAIN ? `https://${process.env.REPLIT_DEV_DOMAIN}` : 'http://localhost:5000',
      redirectUri: '/api/auth/callback',
    };
  }

  // Generate secure OAuth URL
  generateInstallUrl(shop: string): string {
    const state = crypto.lib.WordArray.random(32).toString();
    const redirectUri = `${this.config.hostName}${this.config.redirectUri}`;
    
    const params = new URLSearchParams({
      client_id: this.config.apiKey,
      scope: this.config.scopes.join(','),
      redirect_uri: redirectUri,
      state: state,
      grant_options: 'per-user'
    });

    return `https://${shop}/admin/oauth/authorize?${params.toString()}`;
  }

  // Exchange authorization code for access token
  async exchangeCodeForToken(shop: string, code: string): Promise<any> {
    try {
      const tokenUrl = `https://${shop}/admin/oauth/access_token`;
      const redirectUri = `${this.config.hostName}${this.config.redirectUri}`;
      
      const response = await axios.post(tokenUrl, {
        client_id: this.config.apiKey,
        client_secret: this.config.apiSecret,
        code: code,
        redirect_uri: redirectUri,
      });

      return response.data;
    } catch (error) {
      console.error('Token exchange error:', error);
      throw new Error(`Failed to exchange code for token: ${error}`);
    }
  }

  // Verify HMAC signature
  verifyHmac(query: Record<string, string>): boolean {
    try {
      const { hmac, ...params } = query;
      const sortedParams = Object.keys(params)
        .sort()
        .map(key => `${key}=${params[key]}`)
        .join('&');
      
      const calculatedHmac = crypto.HmacSHA256(sortedParams, this.config.apiSecret).toString();
      return calculatedHmac === hmac;
    } catch (error) {
      console.error('HMAC verification error:', error);
      return false;
    }
  }

  // Get shop information
  async getShopInfo(shop: string, accessToken: string): Promise<any> {
    try {
      const shopify = new Shopify({
        shopName: shop.replace('.myshopify.com', ''),
        apiKey: this.config.apiKey,
        password: accessToken,
      });

      return await shopify.shop.get();
    } catch (error) {
      console.error('Shop info error:', error);
      throw error;
    }
  }

  // Get products for pixel detection
  async getProducts(shop: string, accessToken: string): Promise<any> {
    try {
      const shopify = new Shopify({
        shopName: shop.replace('.myshopify.com', ''),
        apiKey: this.config.apiKey,
        password: accessToken,
      });

      return await shopify.product.list({ limit: 10 });
    } catch (error) {
      console.error('Products fetch error:', error);
      throw error;
    }
  }

  // Create webhook for app uninstalls
  async createWebhook(shop: string, accessToken: string, topic: string, address: string): Promise<any> {
    try {
      const shopify = new Shopify({
        shopName: shop.replace('.myshopify.com', ''),
        apiKey: this.config.apiKey,
        password: accessToken,
      });

      return await shopify.webhook.create({
        webhook: {
          topic: topic,
          address: address,
          format: 'json'
        }
      });
    } catch (error) {
      console.error('Webhook creation error:', error);
      throw error;
    }
  }

  // Detect pixels in theme (simulated for MVP)
  async detectPixels(shop: string, accessToken: string): Promise<any[]> {
    try {
      // In a real implementation, this would analyze the theme files
      // For MVP, we'll return realistic pixel data
      return [
        {
          id: 'meta-facebook',
          name: 'Meta Facebook Pixel',
          status: 'active',
          description: 'Retargeting and social conversions for Facebook & Instagram',
          pixelId: '764100853'
        },
        {
          id: 'google-analytics-4',
          name: 'Google Analytics 4',
          status: 'active',
          description: 'Website web analytics tools for customer journey insights',
          pixelId: 'G-CMD4'
        },
        {
          id: 'google-ads',
          name: 'Google Ads',
          status: 'active',
          description: 'Google Ads conversion tracking and remarketing',
          pixelId: 'AW-1403080'
        },
        {
          id: 'tiktok-pixel',
          name: 'TikTok Pixel',
          status: 'active',
          description: 'Conversion tracking for TikTok ads',
          pixelId: 'C9JS2JHC77UDHOMUB83G'
        },
        {
          id: 'snapchat-pixel',
          name: 'Snapchat Pixel',
          status: 'inactive',
          description: 'Track conversions and build audiences for Snapchat ads',
          pixelId: null
        }
      ];
    } catch (error) {
      console.error('Pixel detection error:', error);
      return [];
    }
  }

  // Generate JWT token for secure sessions
  generateJWT(payload: any): string {
    return jwt.sign(payload, this.config.apiSecret, { expiresIn: '24h' });
  }

  // Verify JWT token
  verifyJWT(token: string): any {
    try {
      return jwt.verify(token, this.config.apiSecret);
    } catch (error) {
      console.error('JWT verification error:', error);
      return null;
    }
  }
}

export const shopifyRobustService = new ShopifyRobustService();