import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { shopifyOfficialService } from "./services/shopify-official";
import { validateShopifyRequest, requireAccessToken, type AuthenticatedRequest } from "./middleware/auth";

export async function registerOfficialRoutes(app: Express): Promise<Server> {
  
  // OAuth installation endpoint using official library
  app.get('/api/auth/install', async (req, res) => {
    try {
      const shop = req.query.shop as string;
      if (!shop) {
        return res.status(400).json({ error: 'Shop parameter is required' });
      }

      // Validate shop domain
      const shopDomain = shop.replace(/^https?:\/\//, '').replace(/\/$/, '');
      if (!shopDomain.includes('.myshopify.com')) {
        return res.status(400).json({ error: 'Invalid shop domain format' });
      }

      // Log installation attempt
      await storage.createAuthLog({
        shop: shopDomain,
        action: 'oauth_start',
        status: 'pending',
        details: `Installation initiated for shop: ${shopDomain}`,
      });

      // Generate OAuth URL using official library
      const authUrl = shopifyOfficialService.generateAuthUrl(shopDomain);
      
      console.log('🎯 Redirecting to Shopify OAuth (Official Library):', authUrl);
      res.redirect(authUrl);
    } catch (error) {
      console.error('Install error:', error);
      res.status(500).json({ error: 'Installation failed' });
    }
  });

  // OAuth callback endpoint using official library
  app.get('/api/auth/callback', async (req, res) => {
    try {
      const { code, shop, state } = req.query as Record<string, string>;

      console.log('=== OFFICIAL OAUTH CALLBACK RECEIVED ===');
      console.log('Shop:', shop);
      console.log('Code exists:', !!code);
      console.log('State exists:', !!state);

      if (!code || !shop) {
        console.log('❌ Missing required OAuth parameters');
        return res.status(400).json({ error: 'Missing required OAuth parameters' });
      }

      // Exchange code for token using official library
      console.log('🔄 Exchanging code for access token (Official Library)...');
      const tokenData = await shopifyOfficialService.exchangeCodeForToken(shop, code, state);
      console.log('✅ Access token obtained successfully');

      // Store shop information
      await storage.createShopifyStore({
        shop: tokenData.shop,
        accessToken: tokenData.accessToken,
        scope: tokenData.scope,
        isActive: true,
      });

      console.log('✅ Shop data stored successfully');

      // Log successful installation
      await storage.createAuthLog({
        shop: tokenData.shop,
        action: 'oauth_complete',
        status: 'success',
        details: 'App successfully installed using official Shopify library',
      });

      console.log('🎉 INSTALLATION COMPLETED - Redirecting to dashboard');

      // Redirect to dashboard with success indicator
      res.redirect(`/?shop=${tokenData.shop}&installed=true&official=true`);
    } catch (error) {
      console.error('OAuth callback error:', error);
      const shop = req.query.shop as string;
      if (shop) {
        await storage.createAuthLog({
          shop,
          action: 'oauth_complete',
          status: 'error',
          details: `OAuth callback failed: ${error}`,
        });
      }
      res.status(500).json({ error: 'Authentication failed with official library' });
    }
  });

  // Get app status with real data
  app.get('/api/status', async (req, res) => {
    try {
      const shop = req.query.shop as string;
      if (!shop) {
        return res.status(400).json({ error: 'Shop parameter is required' });
      }

      const store = await storage.getShopifyStore(shop);
      const authLogs = await storage.getAuthLogs(shop, 10);

      // If store is authenticated, get real shop info and pixels
      let shopInfo = null;
      let pixels = [];
      
      if (store?.isActive && store.accessToken) {
        try {
          shopInfo = await shopifyOfficialService.getShopInfo(shop, store.accessToken);
          const pixelsData = await shopifyOfficialService.getPixels(shop, store.accessToken);
          pixels = pixelsData.pixels || [];
        } catch (error) {
          console.error('Error fetching real data:', error);
        }
      }

      res.json({
        authenticated: !!store?.isActive,
        store: store || null,
        shopInfo,
        pixels,
        authLogs,
        usingOfficialLibrary: true,
      });
    } catch (error) {
      console.error('Status check error:', error);
      res.status(500).json({ error: 'Status check failed' });
    }
  });

  // Test installation with real Shopify data
  app.post('/api/test/installation', async (req, res) => {
    try {
      const shop = req.body.shop as string;
      if (!shop) {
        return res.status(400).json({ error: 'Shop parameter is required' });
      }

      const store = await storage.getShopifyStore(shop);
      if (!store?.isActive || !store.accessToken) {
        return res.status(401).json({ error: 'Store not authenticated' });
      }

      // Test with real Shopify API
      const shopInfo = await shopifyOfficialService.getShopInfo(shop, store.accessToken);
      const pixelsData = await shopifyOfficialService.getPixels(shop, store.accessToken);

      await storage.createAuthLog({
        shop,
        action: 'installation_test',
        status: 'success',
        details: `Installation test successful with official library - shop: ${shopInfo.data?.shop?.name}`,
      });

      res.json({
        success: true,
        shopInfo: shopInfo.data?.shop,
        pixels: pixelsData.pixels || [],
        message: 'Installation test completed successfully with official Shopify library',
      });
    } catch (error) {
      console.error('Installation test error:', error);
      const shop = req.body.shop as string;
      if (shop) {
        await storage.createAuthLog({
          shop,
          action: 'installation_test',
          status: 'error',
          details: `Installation test failed: ${error}`,
        });
      }
      res.status(500).json({ error: 'Installation test failed' });
    }
  });

  // Get logs
  app.get('/api/logs', async (req, res) => {
    try {
      const { shop, type, limit } = req.query;
      const logLimit = parseInt(limit as string) || 50;

      let logs: any[] = [];

      if (type === 'auth' || !type) {
        const authLogs = await storage.getAuthLogs(shop as string, logLimit);
        logs.push(...authLogs.map(log => ({ ...log, type: 'auth' })));
      }

      // Sort by timestamp
      logs.sort((a, b) => {
        const timeA = a.timestamp || a.processedAt;
        const timeB = b.timestamp || b.processedAt;
        return (timeB?.getTime() || 0) - (timeA?.getTime() || 0);
      });

      res.json(logs.slice(0, logLimit));
    } catch (error) {
      console.error('Logs fetch error:', error);
      res.status(500).json({ error: 'Failed to fetch logs' });
    }
  });

  // Configuration test
  app.get('/api/test/config', async (req, res) => {
    try {
      const config = {
        hasApiKey: !!process.env.SHOPIFY_API_KEY,
        hasApiSecret: !!process.env.SHOPIFY_API_SECRET,
        hostName: process.env.REPLIT_DEV_DOMAIN ? `https://${process.env.REPLIT_DEV_DOMAIN}` : 'http://localhost:5000',
        usingOfficialLibrary: true,
        libraryVersion: '@shopify/shopify-api',
      };
      
      console.log('Configuration test (Official Library):', config);
      res.json(config);
    } catch (error) {
      console.error('Config test error:', error);
      res.status(500).json({ error: 'Configuration test failed' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}