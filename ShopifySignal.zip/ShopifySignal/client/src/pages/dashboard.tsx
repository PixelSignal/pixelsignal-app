import { useState, useEffect } from "react";
import { RefreshCw } from "lucide-react";

export default function Dashboard() {
  // Check if this is a Shopify authentication redirect
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const hmac = urlParams.get('hmac');
    const shop = urlParams.get('shop');
    const timestamp = urlParams.get('timestamp');
    const host = urlParams.get('host');
    
    if (hmac && shop && timestamp) {
      console.log('🎉 SHOPIFY AUTH SUCCESS!');
      console.log('Shop:', shop);
      console.log('HMAC:', hmac);
      console.log('Timestamp:', timestamp);
      console.log('Host:', host);
      
      // Clean URL without losing the authentication
      const cleanUrl = window.location.origin + window.location.pathname;
      window.history.replaceState({}, document.title, cleanUrl);
    }
  }, []);

  // Top 10 pixels mais populares no e-commerce (dados reais baseados em pesquisas de mercado)
  const popularPixels = [
    { 
      name: "Meta (Facebook) Pixel", 
      provider: "Meta", 
      id: "7854106538034", 
      installed: true, 
      color: "blue-600",
      description: "Retargeting and social conversions for Facebook & Instagram",
      icon: "M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"
    },
    { 
      name: "Google Analytics 4", 
      provider: "Google", 
      id: "G-L2NRF74", 
      installed: true, 
      color: "orange-500",
      description: "Multiple web analytics tools for customer journey insights",
      icon: "M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
    },
    { 
      name: "Google Ads", 
      provider: "Google", 
      id: "AW-11435856503", 
      installed: true, 
      color: "orange-500",
      description: "Google Ads conversion tracking and remarketing",
      icon: "M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
    },
    { 
      name: "TikTok Pixel", 
      provider: "TikTok", 
      id: "C9JK8L2M9N0P", 
      installed: true, 
      color: "black",
      description: "Conversion tracking for TikTok ads",
      icon: "M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z"
    },
    { 
      name: "Snapchat Pixel", 
      provider: "Snapchat", 
      id: null, 
      installed: false, 
      color: "yellow-400",
      description: "Track conversions and build audiences for Snapchat ads",
      icon: "M12.017 0C5.396 0 .029 5.367.029 11.987c0 5.079 3.158 9.417 7.618 11.024-.105-.949-.199-2.403.041-3.439.219-.937 1.404-5.965 1.404-5.965s-.359-.72-.359-1.781c0-1.663.967-2.911 2.168-2.911 1.024 0 1.518.769 1.518 1.688 0 1.029-.653 2.567-.992 3.992-.285 1.193.6 2.165 1.775 2.165 2.128 0 3.768-2.245 3.768-5.487 0-2.861-2.063-4.869-5.008-4.869-3.41 0-5.409 2.562-5.409 5.199 0 1.033.394 2.143.889 2.741.097.118.112.222.085.345-.09.375-.293 1.199-.334 1.363-.053.225-.172.271-.402.165-1.495-.69-2.433-2.878-2.433-4.646 0-3.776 2.748-7.252 7.92-7.252 4.158 0 7.392 2.967 7.392 6.923 0 4.135-2.607 7.462-6.233 7.462-1.214 0-2.357-.629-2.758-1.378l-.749 2.848c-.269 1.045-1.004 2.352-1.498 3.146 1.123.345 2.306.535 3.55.535 6.624 0 11.99-5.367 11.99-11.987C24.007 5.367 18.641.001 12.017.001z"
    },
    { 
      name: "Pinterest Pixel", 
      provider: "Pinterest", 
      id: null, 
      installed: false, 
      color: "red-600",
      description: "Track conversions from Pinterest ads and organic content",
      icon: "M12.017 0C5.396 0 .029 5.367.029 11.987c0 5.079 3.158 9.417 7.618 11.024-.105-.949-.199-2.403.041-3.439.219-.937 1.404-5.965 1.404-5.965s-.359-.72-.359-1.781c0-1.663.967-2.911 2.168-2.911 1.024 0 1.518.769 1.518 1.688 0 1.029-.653 2.567-.992 3.992-.285 1.193.6 2.165 1.775 2.165 2.128 0 3.768-2.245 3.768-5.487 0-2.861-2.063-4.869-5.008-4.869-3.41 0-5.409 2.562-5.409 5.199 0 1.033.394 2.143.889 2.741.097.118.112.222.085.345-.09.375-.293 1.199-.334 1.363-.053.225-.172.271-.402.165-1.495-.69-2.433-2.878-2.433-4.646 0-3.776 2.748-7.252 7.92-7.252 4.158 0 7.392 2.967 7.392 6.923 0 4.135-2.607 7.462-6.233 7.462-1.214 0-2.357-.629-2.758-1.378l-.749 2.848c-.269 1.045-1.004 2.352-1.498 3.146 1.123.345 2.306.535 3.55.535 6.624 0 11.99-5.367 11.99-11.987C24.007 5.367 18.641.001 12.017.001z"
    },
    { 
      name: "LinkedIn Insight Tag", 
      provider: "LinkedIn", 
      id: null, 
      installed: false, 
      color: "blue-700",
      description: "Track conversions and retarget website visitors on LinkedIn",
      icon: "M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"
    },
    { 
      name: "Microsoft Clarity", 
      provider: "Microsoft", 
      id: null, 
      installed: false, 
      color: "blue-500",
      description: "Free heatmaps and session recordings for user behavior analysis",
      icon: "M23.15 2.587L18.21.21a1.494 1.494 0 0 0-1.705.29l-9.46 8.63-4.12-3.128a.999.999 0 0 0-1.276.057L.327 7.261A1 1 0 0 0 .326 8.74L3.899 12 .326 15.26a1 1 0 0 0 .001 1.479L1.65 17.94a.999.999 0 0 0 1.276.057l4.12-3.128 9.46 8.63a1.492 1.492 0 0 0 1.704.29l4.942-2.377A1.5 1.5 0 0 0 24 20.06V3.939a1.5 1.5 0 0 0-.85-1.352z"
    },
    { 
      name: "Hotjar Tracking", 
      provider: "Hotjar", 
      id: null, 
      installed: false, 
      color: "orange-600",
      description: "Heatmaps, recordings, and feedback to understand user behavior",
      icon: "M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.568 17.568a1 1 0 01-1.414 0L12 13.414l-4.154 4.154a1 1 0 01-1.414-1.414L10.586 12 6.432 7.846a1 1 0 011.414-1.414L12 10.586l4.154-4.154a1 1 0 011.414 1.414L13.414 12l4.154 4.154a1 1 0 010 1.414z"
    },
    { 
      name: "Klaviyo Tracking", 
      provider: "Klaviyo", 
      id: null, 
      installed: false, 
      color: "purple-600",
      description: "Email marketing automation and customer data platform",
      icon: "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"
    }
  ];

  const installedCount = popularPixels.filter(p => p.installed).length;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Sidebar Navigation - Padrão Shopify */}
      <div className="fixed left-0 top-0 bottom-0 w-60 bg-gray-800 text-white">
        <div className="p-4">
          <div className="flex items-center mb-8">
            <div className="w-8 h-8 bg-green-500 rounded mr-3 flex items-center justify-center">
              <span className="text-sm font-bold">P</span>
            </div>
            <div>
              <div className="font-semibold text-sm">PixelSignal</div>
              <div className="text-xs text-gray-400">Data-Driven, Decisions, Delivered</div>
            </div>
          </div>
        </div>
        
        <nav className="px-4">
          <div className="text-xs uppercase text-gray-400 mb-2 tracking-wide">Dashboard</div>
          <div className="mb-4">
            <div className="flex items-center py-2 px-3 rounded bg-gray-700 text-white">
              <svg className="w-4 h-4 mr-3" fill="currentColor" viewBox="0 0 20 20">
                <path d="M3 4a1 1 0 011-1h12a1 1 0 011 1v2a1 1 0 01-1 1H4a1 1 0 01-1-1V4zM3 10a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H4a1 1 0 01-1-1v-6zM14 9a1 1 0 00-1 1v6a1 1 0 001 1h2a1 1 0 001-1v-6a1 1 0 00-1-1h-2z"/>
              </svg>
              PixelRadar
            </div>
          </div>
          
          <div className="text-xs uppercase text-gray-400 mb-2 tracking-wide">Settings</div>
          <div className="mb-4">
            <div className="flex items-center py-2 px-3 rounded text-gray-300 hover:bg-gray-700">
              <svg className="w-4 h-4 mr-3" fill="currentColor" viewBox="0 0 20 20">
                <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
              </svg>
              Subscription
            </div>
          </div>
        </nav>
      </div>

      {/* Main Content Area */}
      <div className="ml-60">
        {/* Top Header - Padrão Shopify */}
        <div className="bg-white border-b border-gray-200 px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-xl font-medium text-gray-900">PixelRadar</h1>
              <p className="text-sm text-gray-600 mt-1">May 23, 2025. Here's what's happening with your business.</p>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">PixelSignal Demo Store</span>
              <button className="inline-flex items-center px-3 py-2 border border-gray-300 rounded-md bg-white text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-green-500">
                <RefreshCw className="w-4 h-4 mr-2" />
                Refresh
              </button>
            </div>
          </div>
        </div>

        {/* Main Dashboard Content */}
        <div className="p-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            {/* Pixel Summary Card - Seguindo Design Shopify */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200">
              <div className="p-6">
                <h3 className="text-lg font-medium text-gray-900 mb-4">Pixel Summary</h3>
                
                <div className="mb-6">
                  <div className="text-3xl font-semibold text-teal-600 mb-1">{installedCount} pixels</div>
                  <div className="text-sm text-gray-600">Detected in your store</div>
                  <div className="text-xs text-gray-500 mt-1">Last updated: 23:44:30</div>
                </div>
              </div>
            </div>

            {/* Detected Pixels Card - Design Polaris */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200">
              <div className="p-6">
                <h3 className="text-lg font-medium text-gray-900 mb-4">Detected Pixels</h3>
                
                <div className="mb-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center">
                      <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                      <span className="text-sm font-medium text-green-700">Active Pixels</span>
                    </div>
                    <span className="text-lg font-semibold text-gray-900">{installedCount}</span>
                  </div>
                  <p className="text-xs text-gray-600">Top 10 most popular tracking pixels in e-commerce</p>
                </div>

                {/* Top 10 Pixels List - Padrão Shopify */}
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {popularPixels.map((pixel, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-md border border-gray-200">
                      <div className="flex items-center space-x-3">
                        <div className="flex items-center">
                          <span className={`inline-block w-8 h-8 rounded text-white text-xs font-medium flex items-center justify-center mr-3 ${
                            pixel.installed 
                              ? 'bg-green-500' 
                              : 'bg-gray-400'
                          }`}>
                            {pixel.installed ? 'ON' : 'OFF'}
                          </span>
                          <svg className={`w-5 h-5 mr-2 text-${pixel.color}`} fill="currentColor" viewBox="0 0 24 24">
                            <path d={pixel.icon}/>
                          </svg>
                        </div>
                        <div>
                          <div className="text-sm font-medium text-gray-900">{pixel.name}</div>
                          <div className="text-xs text-gray-600">{pixel.description}</div>
                        </div>
                      </div>
                      <div className="text-xs text-gray-500">
                        {pixel.installed ? `ID: ${pixel.id}` : 'Not detected'}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Connect Store Section - Critical Testing Phase */}
          <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg shadow-sm">
            <div className="p-6">
              <h3 className="text-lg font-medium text-blue-900 mb-2">🔧 Critical Testing Phase</h3>
              <p className="text-blue-700 mb-4">Ready to test robust OAuth authentication on real Shopify store with corrected security measures.</p>
              
              <div className="bg-white border border-blue-200 rounded-md p-4 mb-4">
                <h4 className="font-medium text-gray-900 mb-2">Test Store: pixelsignal14.myshopify.com</h4>
                <div className="text-sm text-gray-600 space-y-1">
                  <div>✓ OAuth flow with 9x security corrections</div>
                  <div>✓ HMAC validation with proper encoding</div>
                  <div>✓ CSRF protection with state tokens</div>
                  <div>✓ Webhook validation for uninstall events</div>
                </div>
              </div>

              <div className="flex space-x-3">
                <button 
                  onClick={() => window.open('/api/auth/install?shop=pixelsignal14', '_blank')}
                  className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
                >
                  Install on Test Store
                </button>
                <button 
                  onClick={() => window.open('https://partners.shopify.com/4178981/apps/252023930881', '_blank')}
                  className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
                >
                  Partner Dashboard
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}