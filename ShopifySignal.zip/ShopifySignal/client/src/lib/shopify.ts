import { apiRequest } from './queryClient';

export interface AppStatus {
  authenticated: boolean;
  store: any;
  shopInfo: any;
  pixels: any[];
  authLogs: any[];
  systemVersion: string;
}

export interface LogEntry {
  id: number;
  type: 'auth' | 'webhook';
  shop: string;
  action?: string;
  topic?: string;
  status: string;
  details?: string;
  timestamp?: string;
  processedAt?: string;
  hmacValid?: boolean;
}

export async function getAppStatus(shop: string): Promise<AppStatus> {
  const response = await apiRequest('GET', `/api/status?shop=${encodeURIComponent(shop)}`);
  return response.json();
}

export async function testInstallation(shop: string): Promise<{ success: boolean; message: string; shopInfo?: any }> {
  const response = await apiRequest('POST', `/api/test/installation?shop=${encodeURIComponent(shop)}`);
  return response.json();
}

export async function getLogs(shop?: string, type?: 'auth' | 'webhook', limit = 50): Promise<LogEntry[]> {
  const params = new URLSearchParams();
  if (shop) params.append('shop', shop);
  if (type) params.append('type', type);
  params.append('limit', limit.toString());
  
  const response = await apiRequest('GET', `/api/logs?${params.toString()}`);
  return response.json();
}

export function getShopFromUrl(): string | null {
  if (typeof window === 'undefined') return null;
  
  const urlParams = new URLSearchParams(window.location.search);
  return urlParams.get('shop');
}

export function generateInstallUrl(shop: string): string {
  return `/api/auth/install?shop=${encodeURIComponent(shop)}`;
}
