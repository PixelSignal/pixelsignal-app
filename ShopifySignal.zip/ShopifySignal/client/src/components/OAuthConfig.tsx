import { Card, CardContent } from "@/components/ui/card";

const requiredScopes = [
  'read_products',
  'write_products', 
  'read_orders',
  'read_analytics'
];

const redirectUrls = [
  `${window.location.origin}/api/auth/callback`,
  `${window.location.origin}/auth/shopify/callback`
];

export function OAuthConfig() {
  return (
    <Card className="shadow-sm border border-gray-200">
      <CardContent className="p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">OAuth Configuration</h3>
        
        <div className="space-y-4">
          <div className="bg-gray-50 rounded-lg p-4">
            <h4 className="text-sm font-medium text-gray-900 mb-2">Required Scopes</h4>
            <div className="flex flex-wrap gap-2">
              {requiredScopes.map((scope) => (
                <span 
                  key={scope}
                  className="bg-blue-100 text-blue-800 text-xs font-medium px-2.5 py-1 rounded-full"
                >
                  {scope}
                </span>
              ))}
            </div>
          </div>

          <div className="bg-gray-50 rounded-lg p-4">
            <h4 className="text-sm font-medium text-gray-900 mb-2">Redirect URLs</h4>
            <div className="space-y-2">
              {redirectUrls.map((url) => (
                <div key={url} className="flex items-center space-x-2">
                  <div className="w-4 h-4 rounded-full bg-green-500 flex items-center justify-center">
                    <svg className="w-2 h-2 text-white" fill="currentColor" viewBox="0 0 8 8">
                      <path d="M6.564.75l-3.59 3.612-1.538-1.55L0 4.26l2.974 2.99L8 2.193z"/>
                    </svg>
                  </div>
                  <code className="text-xs font-mono bg-white px-2 py-1 rounded border">
                    {url}
                  </code>
                </div>
              ))}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
