import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { getLogs, type LogEntry } from "@/lib/shopify";
import { RefreshCw, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface DevelopmentLogsProps {
  shop: string | null;
}

export function DevelopmentLogs({ shop }: DevelopmentLogsProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: logs = [], isLoading, refetch } = useQuery({
    queryKey: ['/api/logs', shop],
    queryFn: () => getLogs(shop || undefined),
    enabled: true,
    refetchInterval: 5000, // Refresh every 5 seconds
  });

  const handleRefresh = () => {
    refetch();
    toast({
      title: "Logs Refreshed",
      description: "Development logs have been updated.",
    });
  };

  const handleClear = () => {
    queryClient.setQueryData(['/api/logs', shop], []);
    toast({
      title: "Logs Cleared",
      description: "Log display has been cleared locally.",
    });
  };

  const formatTimestamp = (timestamp: string) => {
    return new Date(timestamp).toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      second: '2-digit',
      hour12: true,
    });
  };

  const getLogColor = (log: LogEntry) => {
    if (log.type === 'auth') {
      switch (log.status) {
        case 'success': return 'text-green-400';
        case 'error': return 'text-red-400';
        case 'pending': return 'text-yellow-400';
        default: return 'text-blue-400';
      }
    } else {
      return log.hmacValid === false ? 'text-red-400' : 'text-green-400';
    }
  };

  const formatLogMessage = (log: LogEntry) => {
    const timestamp = formatTimestamp(log.timestamp || log.processedAt || '');
    const type = log.type === 'auth' ? 'AUTH' : 'WEBHOOK';
    
    if (log.type === 'auth') {
      return `[${timestamp}] ${type}: ${log.action} - ${log.status} - ${log.details || ''}`;
    } else {
      return `[${timestamp}] ${type}: ${log.topic} from ${log.shop} - HMAC: ${log.hmacValid ? 'valid' : 'invalid'}`;
    }
  };

  return (
    <div>
      {logs.length === 0 ? (
        <div className="text-gray-400">Aguardando logs... Faça testes para ver as informações aparecerem aqui.</div>
      ) : (
        <div className="space-y-1">
          {logs.map((log, index) => (
            <div key={`${log.id}-${index}`} className={getLogColor(log)}>
              {formatLogMessage(log)}
            </div>
          ))}
          <div className="text-gray-400 animate-pulse">▋</div>
        </div>
      )}
    </div>
  );
}
