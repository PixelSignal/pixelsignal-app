import { cn } from "@/lib/utils";
import { Check, Clock, AlertCircle } from "lucide-react";

interface ProgressStepProps {
  step: number;
  title: string;
  description: string;
  status: 'completed' | 'in-progress' | 'pending' | 'error';
  actionLabel?: string;
  onAction?: () => void;
}

const statusConfig = {
  completed: {
    icon: Check,
    iconBg: 'bg-green-500',
    iconColor: 'text-white',
    badge: { text: 'Completed', bg: 'bg-green-100', color: 'text-green-800' },
    titleColor: 'text-gray-900'
  },
  'in-progress': {
    icon: null,
    iconBg: 'bg-yellow-500',
    iconColor: 'text-white',
    badge: { text: 'In Progress', bg: 'bg-yellow-100', color: 'text-yellow-800' },
    titleColor: 'text-gray-900'
  },
  pending: {
    icon: null,
    iconBg: 'bg-gray-300',
    iconColor: 'text-gray-600',
    badge: { text: 'Pending', bg: 'bg-gray-100', color: 'text-gray-600' },
    titleColor: 'text-gray-500'
  },
  error: {
    icon: AlertCircle,
    iconBg: 'bg-red-500',
    iconColor: 'text-white',
    badge: { text: 'Error', bg: 'bg-red-100', color: 'text-red-800' },
    titleColor: 'text-gray-900'
  }
};

export function ProgressStep({ step, title, description, status, actionLabel, onAction }: ProgressStepProps) {
  const config = statusConfig[status];
  const Icon = config.icon;

  return (
    <div className="flex items-start space-x-4">
      <div className="flex-shrink-0">
        <div className={cn("w-8 h-8 rounded-full flex items-center justify-center", config.iconBg)}>
          {Icon ? (
            <Icon className={cn("text-sm", config.iconColor)} />
          ) : (
            <span className={cn("text-xs font-semibold", config.iconColor)}>{step}</span>
          )}
        </div>
      </div>
      <div className="flex-1">
        <h4 className={cn("text-sm font-medium", config.titleColor)}>
          {step}. {title}
        </h4>
        <p className={cn("text-sm", status === 'pending' ? 'text-gray-500' : 'text-gray-600')}>
          {description}
        </p>
        <div className="mt-2 flex items-center space-x-2">
          <span className={cn("text-xs font-medium px-2 py-1 rounded", config.badge.bg, config.badge.color)}>
            {config.badge.text}
          </span>
          {actionLabel && onAction && status !== 'pending' && (
            <button 
              onClick={onAction}
              className="text-xs text-blue-600 hover:text-blue-800 font-medium transition-colors"
            >
              {actionLabel}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
