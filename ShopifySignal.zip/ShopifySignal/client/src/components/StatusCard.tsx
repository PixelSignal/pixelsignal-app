import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface StatusCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  status: 'success' | 'warning' | 'error' | 'neutral';
  className?: string;
}

const statusStyles = {
  success: {
    value: 'text-green-600',
    background: 'bg-green-100',
    icon: 'text-green-600'
  },
  warning: {
    value: 'text-yellow-600',
    background: 'bg-yellow-100',
    icon: 'text-yellow-600'
  },
  error: {
    value: 'text-red-600',
    background: 'bg-red-100',
    icon: 'text-red-600'
  },
  neutral: {
    value: 'text-gray-900',
    background: 'bg-gray-100',
    icon: 'text-gray-600'
  }
};

export function StatusCard({ title, value, icon, status, className }: StatusCardProps) {
  const styles = statusStyles[status];

  return (
    <Card className={cn("shadow-sm border border-gray-200", className)}>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-600">{title}</p>
            <p className={cn("text-2xl font-bold", styles.value)}>{value}</p>
          </div>
          <div className={cn("w-12 h-12 rounded-lg flex items-center justify-center", styles.background)}>
            <div className={cn("text-lg", styles.icon)}>
              {icon}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
