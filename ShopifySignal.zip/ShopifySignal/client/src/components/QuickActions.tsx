import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Download, Webhook, Shield, ExternalLink } from "lucide-react";

interface QuickActionsProps {
  shop: string | null;
  onTestInstallation: () => void;
  onValidateWebhooks: () => void;
  onCheckHMAC: () => void;
  isTestingInstallation?: boolean;
}

const officialResources = [
  {
    title: "Shopify Dev Docs",
    url: "https://shopify.dev/docs",
    icon: ExternalLink
  },
  {
    title: "Shopify CLI",
    url: "https://shopify.dev/docs/apps/tools/cli",
    icon: ExternalLink
  },
  {
    title: "Admin REST API",
    url: "https://shopify.dev/docs/api/admin-rest",
    icon: ExternalLink
  },
  {
    title: "Webhooks Guide",
    url: "https://shopify.dev/docs/api/webhooks",
    icon: ExternalLink
  }
];

export function QuickActions({ 
  shop, 
  onTestInstallation, 
  onValidateWebhooks, 
  onCheckHMAC,
  isTestingInstallation = false 
}: QuickActionsProps) {
  const { toast } = useToast();

  const handleResourceClick = (url: string) => {
    window.open(url, '_blank');
  };

  const handleValidateWebhooks = () => {
    toast({
      title: "Webhook Validation",
      description: "Checking webhook configuration...",
    });
    onValidateWebhooks();
  };

  const handleCheckHMAC = () => {
    toast({
      title: "HMAC Validation",
      description: "Verifying HMAC signature validation...",
    });
    onCheckHMAC();
  };

  return (
    <div className="space-y-6">
      {/* Quick Actions */}
      <Card className="shadow-sm border border-gray-200">
        <CardContent className="p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
          <div className="space-y-3">
            <Button 
              onClick={onTestInstallation}
              disabled={!shop || isTestingInstallation}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white"
            >
              <Download className="w-4 h-4 mr-2" />
              {isTestingInstallation ? 'Testing...' : 'Test Installation'}
            </Button>
            <Button 
              onClick={handleValidateWebhooks}
              disabled={!shop}
              variant="outline"
              className="w-full"
            >
              <Webhook className="w-4 h-4 mr-2" />
              Validate Webhooks
            </Button>
            <Button 
              onClick={handleCheckHMAC}
              disabled={!shop}
              variant="outline"
              className="w-full"
            >
              <Shield className="w-4 h-4 mr-2" />
              Check HMAC
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Official Resources */}
      <Card className="shadow-sm border border-gray-200">
        <CardContent className="p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Official Resources</h3>
          <div className="space-y-3">
            {officialResources.map((resource) => (
              <button
                key={resource.url}
                onClick={() => handleResourceClick(resource.url)}
                className="flex items-center space-x-2 text-sm text-blue-600 hover:text-blue-800 transition-colors w-full text-left"
              >
                <resource.icon className="w-4 h-4" />
                <span>{resource.title}</span>
              </button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Development Status */}
      <Card className="shadow-sm border border-gray-200">
        <CardContent className="p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Development Status</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Environment</span>
              <span className="bg-blue-100 text-blue-800 text-xs font-medium px-2 py-1 rounded">
                Development
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">App Template</span>
              <span className="text-xs font-mono bg-gray-100 px-2 py-1 rounded">Node.js</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Shopify CLI</span>
              <span className="text-xs text-green-600 flex items-center">
                <svg className="w-3 h-3 mr-1" fill="currentColor" viewBox="0 0 8 8">
                  <path d="M6.564.75l-3.59 3.612-1.538-1.55L0 4.26l2.974 2.99L8 2.193z"/>
                </svg>
                Installed
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">App Bridge</span>
              <span className="text-xs text-yellow-600 flex items-center">
                <svg className="w-3 h-3 mr-1" fill="currentColor" viewBox="0 0 8 8">
                  <circle cx="4" cy="4" r="3"/>
                </svg>
                Pending
              </span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
